@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title BOT Point v3.9.1

echo ======================================
echo       BOT Point - запуск
 echo ======================================

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python ne naiden. Ustanovite Python i dobavte ego v PATH.
  pause
  exit /b 1
)

if not exist "app.py" (
  echo [ERROR] app.py ne naiden. Polozhite BAT v papku s app.py.
  pause
  exit /b 1
)

if not exist ".env" (
  if exist ".env.example" (
    copy /y ".env.example" ".env" >nul
    echo Sozdan .env iz .env.example.
    echo Zapolnite BOT_TOKEN, CHAT_ID i THREAD_ID v otkryvshemsya faile.
    start "" notepad.exe ".env"
  ) else (
    echo [ERROR] Net .env i .env.example.
  )
  pause
  exit /b 1
)

python -c "import flask, requests, dotenv, telethon, google.auth" >nul 2>&1
if errorlevel 1 (
  echo Ustanovka zavisimostei...
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo [ERROR] Ne udalos ustanovit zavisimosti.
    pause
    exit /b 1
  )
)

for /f "tokens=2 delims==" %%P in ('findstr /b /c:"APP_PORT=" ".env"') do set "BOT_PORT=%%P"
if not defined BOT_PORT set "BOT_PORT=5000"

echo Zapusk servera. Ne zakryvaite eto okno.
echo Adres: http://127.0.0.1:%BOT_PORT%
start "" cmd /c "timeout /t 3 /nobreak >nul & start """" ""http://127.0.0.1:%BOT_PORT%"""
python app.py

echo.
echo Server ostanovlen. Esli byla oshibka, skopiruite tekst vyshe.
pause
