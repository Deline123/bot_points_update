@echo off
cd /d "%~dp0"
python history_sync.py login
pause
