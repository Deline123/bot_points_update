"""Offline end-to-end tests for automatic updates and approval of flagged messages."""
import contextlib
import hashlib
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from test_logic import app, fake

SID='sheetAuto123'
GID='1448578665'
URL=f'https://docs.google.com/spreadsheets/d/{SID}/edit#gid={GID}'
CHAT=-1003160564432
THREAD=176


class AutoApprovalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.db_old,self.chat_old,self.thread_old=app.DB,app.CHAT_ID,app.THREAD_ID
        app.DB=Path(self.temp.name)/'points.db'
        app.CHAT_ID=str(CHAT)
        app.THREAD_ID=str(THREAD)
        app.init_db()
        app.save_default_sheet_url(URL)
        fake.request.method='POST'
        fake.request.remote_addr='127.0.0.1'
        fake.request.headers={}
        fake.request.host_url='http://127.0.0.1:5000/'
        self.current=int(time.time())
        self.snap=dict(title='Products',gid=GID,spreadsheet_id=SID,
                       rows=[['Part','Points','Notes'],['R5G23506','7','keep']],
                       formulas=[],grid_rows=100)
        self.writes=[]
        def write(session,snapshot,cells):
            self.writes.append(list(cells))
            for row,col,v in cells:
                while len(self.snap['rows'])<row:
                    self.snap['rows'].append([])
                while len(self.snap['rows'][row-1])<=col:
                    self.snap['rows'][row-1].append('')
                self.snap['rows'][row-1][col]=str(v)
            return {'totalUpdatedCells':len(cells)}
        self.patches=[
            patch.object(app,'authorize',return_value=contextlib.nullcontext(object())),
            patch.object(app,'read_snapshot',side_effect=lambda session,sid,gid:self.snap),
            patch.object(app,'apply_changes',side_effect=write),
            patch.object(app,'get_service_email',return_value='bot@example.com')]
        for p in self.patches:p.start()
        app.prepared_writes.clear()
        app.auto_state['last_error']=None

    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        app.DB,app.CHAT_ID,app.THREAD_ID=self.db_old,self.chat_old,self.thread_old
        self.temp.cleanup()

    def post(self,route,payload):
        fake.request.get_json=lambda **kw:payload
        return route()

    def save(self,msg_id,text,topic=THREAD):
        with app.connect() as db:
            return app.save_report(db,CHAT,msg_id,topic,self.current,text)

    def test_auto_idempotence_new_reports_and_new_parts(self):
        self.save(1,'R5G23506 Сборщик Ф2\nСложний 7\nОдин1\nКонтролер 1\nИтого 9')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],1)
        self.assertEqual(self.snap['rows'][1][1],'8')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        self.assertEqual(len(self.writes),1)
        # New report with 10 adds *one* round of averaging (8 + 10)/2 = 9,
        # but does not mix in old already accounted 9 again.
        self.save(2,'R5G23506 Другой Ф1\nСложний 10\nИтого 10')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],1)
        self.assertEqual(self.snap['rows'][1][1],'9')
        self.save(3,'NEWPART99 Сборщик Ф1\nКорпус 7\nИтого 7')
        result=app.execute_write(0,1,2)
        self.assertEqual(result['added'],1)
        self.assertEqual(self.snap['rows'][2][:2],['NEWPART99','7'])
        self.assertEqual(self.snap['rows'][1][2],'keep')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)

    def test_pending_review_is_not_written_before_approval(self):
        bad='NEWPART99 Сборщик Ф1\nКорпус 5\nОдин 1\nИтого 9'
        report=self.save(11,bad)
        self.assertEqual(report['status'],'conflict')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        self.assertEqual(len(self.snap['rows']),2)
        app.write_settings(dict(enabled=True,sid=SID,gid=GID,part_col=0,points_col=1,first_row=2,mode='average'))
        response=self.post(app.approve_review,dict(chat_id=CHAT,message_id=11,points=6,
            text_hash=hashlib.sha256(bad.encode()).hexdigest()))
        self.assertTrue(response['approved'])
        self.assertTrue(response['written'])
        self.assertEqual(self.snap['rows'][2][:2],['NEWPART99','6'])
        # Telethon re-reads same message: approval persists.
        again=self.save(11,bad)
        self.assertEqual(again['status'],'approved')
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM review_messages').fetchone()[0],0)
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        # Edited post invalidates approval: old approval is never applied to new text.
        edited=self.save(11,'NEWPART99 Сборщик Ф1\nКорпус 5\nИтого 9')
        self.assertEqual(edited['status'],'conflict')
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM approved_reports').fetchone()[0],0)

    def test_approval_updates_existing_part_once(self):
        bad='R5G23506 Сборщик Ф1\nКорпус 7\nИтого 9'
        self.save(12,bad)
        app.write_settings(dict(enabled=True,sid=SID,gid=GID,part_col=0,points_col=1,first_row=2,mode='average'))
        result=self.post(app.approve_review,dict(chat_id=CHAT,message_id=12,points=9,
            text_hash=hashlib.sha256(bad.encode()).hexdigest()))
        self.assertTrue(result['written'])
        self.assertEqual(self.snap['rows'][1][1],'8')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        self.assertEqual(self.snap['rows'][1][1],'8')
        again=self.post(app.approve_review,dict(chat_id=CHAT,message_id=12,points=9,
            text_hash=hashlib.sha256(bad.encode()).hexdigest()))
        self.assertEqual(again[1],409)

    def test_noop_is_also_processed_exactly_once(self):
        self.save(13,'R5G23506 Сборщик Ф2\nКорпус 7\nИтого 7')
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        p=app.pending_telegram_points(SID,GID,'average',self.current-10,self.current+10)
        self.assertEqual(p,{})

    def test_google_timeout_after_remote_success_is_not_duplicated(self):
        self.save(20,'R5G23506 Сборщик Ф1\nКорпус 9\nИтого 9')
        orig=app.apply_changes
        def timeout_after_write(*args,**kw):
            orig(*args,**kw)
            raise app.SheetWriteError('Ответ Google потерян')
        with patch.object(app,'apply_changes',side_effect=timeout_after_write):
            with self.assertRaises(app.SheetWriteError):
                app.execute_write(0,1,2)
        self.assertEqual(self.snap['rows'][1][1],'8')
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM sheet_pending_jobs').fetchone()[0],1)
        # Next run sees completed remote write and commits its evidence only.
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        self.assertEqual(self.snap['rows'][1][1],'8')
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM sheet_pending_jobs').fetchone()[0],0)

    def test_upgrade_from_v38_ledger_migration_skips_old_messages(self):
        raw='R5G23506 Сборщик Ф2\nКорпус 9\nИтого 9'
        self.save(101,raw)
        with app.connect() as db:
            db.execute('INSERT INTO sheet_applied(spreadsheet_id,gid,part,fingerprint,written_value,updated_utc) '
                'VALUES(?,?,?,?,?,?)',(SID,GID,'R5G23506','old_hash','8',self.current+5))
        self.snap['rows'][1][1]='8'  # v3.8 already wrote this report
        self.assertEqual(app.execute_write(0,1,2)['updated_cells'],0)
        self.assertEqual(self.snap['rows'][1][1],'8')
        # Fresh incoming report is newer than old v3.8 writer timestamp.
        future=self.current+30
        with app.connect() as db:
            app.save_report(db,CHAT,102,THREAD,future,'R5G23506 Другой Ф1\nКорпус 10\nИтого 10')
        result=app.execute_write(0,1,2)
        self.assertEqual(result['updated_cells'],1)
        self.assertEqual(self.snap['rows'][1][1],'9')

    def test_settings_persist_and_disabling(self):
        data=self.post(app.auto_write_settings_route,dict(enabled=True,part_col=0,points_col=1,first_row=2,mode='average'))
        self.assertTrue(data['enabled'])
        self.assertTrue(app.auto_settings()['enabled'])
        data=self.post(app.auto_write_settings_route,dict(enabled=False))
        self.assertFalse(data['enabled'])
        self.assertFalse(app.auto_settings()['enabled'])

    def test_review_hash_prevents_stale_approval(self):
        bad='NEWPART99 Сборщик Ф1\nКорпус 5\nИтого 9'
        self.save(1,bad)
        result=self.post(app.approve_review,dict(chat_id=CHAT,message_id=1,points=5,text_hash='stale'))
        self.assertEqual(result[1],409)
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM approved_reports').fetchone()[0],0)


if __name__=='__main__':
    unittest.main()
