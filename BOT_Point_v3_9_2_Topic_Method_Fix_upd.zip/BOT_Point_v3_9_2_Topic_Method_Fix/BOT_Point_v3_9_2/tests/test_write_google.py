"""No external network. Simulate Sheets API and verify the write endpoint behavior."""
import contextlib
import tempfile
import time
from pathlib import Path
from unittest import TestCase
from unittest.mock import patch
from test_logic import app, fake

SID='fakeSpreadsheet123'
GID='1448578665'
URL=f'https://docs.google.com/spreadsheets/d/{SID}/edit#gid={GID}'


def snapshot(rows, formulas=None):
    return dict(title='Партномер + Кол-во поинтов', gid=GID,
        spreadsheet_id=SID, rows=rows, formulas=formulas or [], grid_rows=100)


class WriteTests(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.old_db=app.DB
        self.old_chat,self.old_topic=app.CHAT_ID,app.THREAD_ID
        app.DB=Path(self.tmp.name)/'points.db'
        app.CHAT_ID='-1003160564432'
        app.THREAD_ID='176'
        app.init_db()
        app.save_default_sheet_url(URL)
        fake.request.remote_addr='127.0.0.1'
        fake.request.headers={}
        fake.request.host_url='http://127.0.0.1:5000/'
        app.prepared_writes.clear()
        self.now=int(time.time())
        with app.connect() as c:
            app.save_report(c, -1003160564432, 1, 176, self.now,
                'R5G23506 Элмир Ф2\nСложний 7\nОдин1\nКонтролер 1\nИтого 9')
            app.save_report(c, -1003160564432, 2, 176, self.now,
                'NEWPART99 Иван Ф1\nКорпус 6\n1\nИтого 7')

    def tearDown(self):
        app.DB=self.old_db
        app.CHAT_ID,app.THREAD_ID=self.old_chat,self.old_topic
        app.prepared_writes.clear()
        self.tmp.cleanup()

    def test_plan_updates_only_target_points_and_appends_new_rows(self):
        tg=app.all_telegram_points('average',self.now-10,self.now+100)
        snap=snapshot([['Партномер','Поинты','Комментарий'],['R5G23506','7','keep'],['OTHER999','4','do not touch']])
        preview=app.build_write_preview(snap,0,1,2,tg,{})
        self.assertEqual(preview['updates'],[(2,1,8),(4,0,'NEWPART99'),(4,1,7)])
        self.assertEqual(preview['added'],1)
        self.assertEqual(preview['changed'],1)
        self.assertEqual(preview['results'][-1]['row'],4)
        self.assertTrue('NEWPART99\t7' in preview['new_pairs'])

    def test_prevents_double_averaging_after_successful_write(self):
        snap=snapshot([['Партномер','Поинты'],['R5G23506','7']])
        fake.request.get_json=lambda **kwargs:dict(part_col=0,points_col=1,first_row=2,mode='average')
        def fake_api_write(session, sheet_snapshot, cells):
            for row,column,value in cells:
                while len(snap['rows']) < row:
                    snap['rows'].append([])
                while len(snap['rows'][row-1]) <= column:
                    snap['rows'][row-1].append('')
                snap['rows'][row-1][column]=str(value)
            return {'totalUpdatedCells':len(cells)}
        with patch.object(app,'authorize', return_value=contextlib.nullcontext(object())), \
            patch.object(app,'read_snapshot',side_effect=lambda session,sid,gid: snap), \
            patch.object(app,'apply_changes',side_effect=fake_api_write):
            plan=app.prepare_write()
            self.assertEqual(plan['changed'],1)
            self.assertEqual(plan['added'],1)
            self.assertTrue(plan['has_changes'])
            fake.request.get_json=lambda **kwargs:{'plan_token':plan['plan_token']}
            outcome=app.apply_write()
            self.assertTrue(outcome['ok'])
            self.assertEqual(outcome['updated_cells'],3)
            self.assertEqual(snap['rows'][1][1], '8')
            self.assertEqual(snap['rows'][2], ['NEWPART99','7'])
            fake.request.get_json=lambda **kwargs:dict(part_col=0,points_col=1,first_row=2,mode='average')
            repeat=app.prepare_write()
            self.assertFalse(repeat['has_changes'])
            self.assertEqual(repeat['changed'],0)
            self.assertEqual(repeat['added'],0)
            self.assertEqual(repeat['results'][0]['output'], '8')
            self.assertEqual(repeat['results'][0]['status'],'Уже учтён')

    def test_stale_snapshot_is_not_written(self):
        snap=snapshot([['Партномер','Поинты'],['R5G23506','7']])
        fake.request.get_json=lambda **kwargs:dict(part_col=0,points_col=1,first_row=2,mode='average')
        with patch.object(app,'authorize', return_value=contextlib.nullcontext(object())), \
            patch.object(app,'read_snapshot',side_effect=lambda session,sid,gid: snap), \
            patch.object(app,'apply_changes') as write:
            plan=app.prepare_write()
            snap['rows'][1][1]='99'
            fake.request.get_json=lambda **kwargs:{'plan_token':plan['plan_token']}
            response, code=app.apply_write()
            self.assertEqual(code,409)
            self.assertIn('изменена',response['error'])
            write.assert_not_called()

    def test_duplicate_parts_rejected(self):
        tg=app.all_telegram_points('average',self.now-10,self.now+10)
        snap=snapshot([['Партномер','Поинты'],['R5G23506','7'],['r5g23506','8']])
        with self.assertRaisesRegex(ValueError,'повторяется'):
            app.build_write_preview(snap,0,1,2,tg,{})

    def test_formula_cells_preserved(self):
        tg=app.all_telegram_points('average',self.now-10,self.now+10)
        snap=snapshot([['Партномер','Поинты'],['R5G23506','7']],
            [['Партномер','Поинты'],['R5G23506','=SUM(B100:B120)']])
        with self.assertRaisesRegex(ValueError,'формулой'):
            app.build_write_preview(snap,0,1,2,tg,{})

    def test_requests_from_outside_localhost_refused(self):
        fake.request.remote_addr='192.168.1.30'
        fake.request.get_json=lambda **kwargs:dict(part_col=0,points_col=1,first_row=2)
        response,status=app.prepare_write()
        self.assertEqual(status,403)
        self.assertIn('только с этого компьютера',response['error'])

    def test_cell_reference_format(self):
        from google_sheets_writer import index_to_col, quoted_title
        self.assertEqual(index_to_col(0),'A')
        self.assertEqual(index_to_col(27),'AB')
        self.assertEqual(quoted_title("John's tab"),"'John''s tab'")
