"""Offline tests; Flask/Telethon network access not needed."""
import importlib.util
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path

# The production app uses Flask; lightweight stubs let these pure-logic tests
# run on a computer without installing any dependencies or contacting Telegram.
fake = types.ModuleType('flask')
class AppStub:
    def __init__(self, *args, **kwargs): self.secret_key = None
    def route(self, *args, **kwargs): return lambda f: f
fake.Flask = AppStub
fake.render_template = lambda name: name
fake.jsonify = lambda **kwargs: kwargs
fake.request = types.SimpleNamespace(get_json=lambda **kwargs: {})
sys.modules['flask'] = fake
spec = importlib.util.spec_from_file_location('bot_point_logic', str(Path(__file__).resolve().parents[1] / 'app.py'))
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)

class LogicTests(unittest.TestCase):
    def test_reports(self):
        cases = [
            ('R5G23506 Элмир Ф2\nСложний 7\nОдин1\nКонтролер 1\nИтого 9', 9, 'verified'),
            ('A5600.16.S10.5060.B1679 Элмир Ф2\nСложний 7\nОдин1\nКонтролер 1\n9', 9, 'verified'),
            ('R5G23506 Ф2\nСложний 7\nМонтаж 1\nЕщё какой-то пункт 1\n9', 9, 'verified'),
            ('R5G23506 Ф2\nСложний 7\nОдин1\nКонтролер 1', 9, 'calculated'),
            ('R5G23506 Ф2\nСложний 7\nОдин1\nКонтролер 1\nИТОГО: 10', None, 'conflict'),
            ('R5G23506 Ф2\nСложний 7\nОдин1\nКонтролер 1\n10', None, 'conflict'),
            ('R5G23506 Ф2\nСложний 7\nОдин1\nКонтролер 1\nВсего 9', 9, 'verified'),
            ('R5G23506 Ф2\nИтого 9', 9, 'last_only'),
            ('R5G23506 Ф2\nКорпус 5\nЧужой пункт 2\nКонтролер 1', 8, 'calculated'),
            ('R5G23506 Ф2\nОдин1\nВода2\nРазом 3', 3, 'verified'),
            ('R5G23506 Ф2\nСтрока без числа', None, 'review'),
        ]
        for raw, expected, status in cases:
            with self.subTest(raw=raw):
                parsed = app.parse_report(raw)
                self.assertEqual(parsed['points'], expected, parsed)
                self.assertEqual(parsed['status'], status, parsed)

    def test_sheet_values(self):
        checks = [
            ('7', 9, ('8','Усреднён')),
            ('9', 9, ('9','Совпадает')),
            ('9,0', 9, ('9,0','Совпадает')),
            ('8', 9, ('9','Усреднён')),
            ('10', 7, ('9','Усреднён')),
            ('', 8, ('8','Заполнен')),
            ('не задано', 8, ('8','Заполнен')),
            ('6', None, ('6','Не найден')),
        ]
        for old, new, exp in checks:
            with self.subTest(old=old,new=new):
                self.assertEqual(app.merged_sheet_value(old,new),exp)

    def test_appends_new_telegram_parts_and_preserves_internal_blanks(self):
        with tempfile.TemporaryDirectory() as tmp:
            app.DB = Path(tmp) / 'points.db'
            app.CHAT_ID = '-1003160564432'
            app.THREAD_ID = '176'
            app.init_db()
            now = int(time.time())
            with app.connect() as db:
                app.save_report(db, -1003160564432, 10, 176, now - 70,
                    'R5G23506 Сборщик Ф2\nКорпус 7\nОдин 2\nИтого 9')
                app.save_report(db, -1003160564432, 11, 176, now - 60,
                    'NEWPART99 Сборщик Ф1\nКорпус 5\nОдин 1\n6')
                app.save_report(db, -1003160564432, 12, 176, now - 50,
                    'ANOTHER88 Сборщик Ф1\nСложний 9\nИтого 9')
                app.save_report(db, -1003160564432, 13, 176, now - 40,
                    'NEWPART99 Сборщик Ф1\nКорпус 6\nОдин 1\n7')
                # Wrong topic: must never appear in Google output.
                app.save_report(db, -1003160564432, 14, 177, now - 30,
                    'OTHER999 Сборщик Ф1\nКорпус 5\n5')
                # Incorrect breakdown: reviewed but not appended.
                app.save_report(db, -1003160564432, 15, 176, now - 20,
                    'WRONG999 Сборщик Ф1\nКорпус 5\nИтого 8')
            fake.request.get_json = lambda **kwargs: {
                'rows': [
                    {'part':'r5g23506','old':'7'},
                    {'part':'','old':''},
                    {'part':'KEEP999','old':'3'},
                    {'part':'','old':''},  # trailing empty line trimmed
                ],
                'mode':'average',
            }
            response = app.compare_sheet()
            # 9 Telegram vs 7 Google -> 8. NEWPART99 mean(6,7)=ceil(6.5)=7.
            self.assertEqual(response['two_columns'],
                'r5g23506\t8\n\t\nKEEP999\t3\nNEWPART99\t7\nANOTHER88\t9')
            self.assertEqual(response['column'], '8\n\n3\n7\n9')
            self.assertEqual(response['part_column'], 'r5g23506\n\nKEEP999\nNEWPART99\nANOTHER88')
            self.assertEqual(response['new_pairs'], 'NEWPART99\t7\nANOTHER88\t9')
            self.assertEqual(response['added'], 2)
            self.assertEqual(response['original'], 3)
            self.assertEqual(response['total'], 5)
            self.assertEqual(response['changed'], 1)
            self.assertEqual(response['missing'], 1)
            self.assertEqual(response['results'][-1]['status'], 'Новый партномер')

    def test_new_part_found_in_google_is_not_appended_twice(self):
        all_points = {
            'PART123': {'points': 8},
            'EXTRA789': {'points': 5},
        }
        result = app.combine_sheet_with_telegram([
            ('PART123','PART123','8'),
            ('PART123','PART123','6'),
            ('','', ''),
        ], all_points)
        self.assertEqual(result['added'], 1)
        self.assertEqual(result['two_columns'],
                         'PART123\t8\nPART123\t7\nEXTRA789\t5')

    def test_end_to_end_ordered_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            app.DB = Path(tmp) / 'points.db'
            app.CHAT_ID = '-1003160564432'
            app.THREAD_ID = '176'
            app.init_db()
            now = int(time.time())
            with app.connect() as db:
                app.save_report(db, -1003160564432, 101, 176, now-100,
                    'R5G23506 Элмир Ф2\nСложний 7\nОдин1\nИтого 8')
                app.save_report(db, -1003160564432, 102, 176, now,
                    'R5G23506 Элмир Ф2\nСложний 8\nОдин1\nИтого 9')
                app.save_report(db, -1003160564432, 103, 176, now,
                    'A5600.16.S10.5060.B1679 Элмир Ф2\nКорпус 5\nИтого 5')
            # Telegram R5... mean(8,9)=8.5 rounded up to 9.
            # Existing Google value 7 -> mean(7,9)=8.
            fake.request.get_json = lambda **kwargs: {
                'rows': [
                    {'part':'R5G23506','old':'7'},
                    {'part':'','old':''},
                    {'part':'A5600.16.S10.5060.B1679','old':'5'},
                    {'part':'UNKNOWN9','old':'13'},
                    {'part':'R5G23506','old':'9'},
                ],
                'mode':'average',
            }
            response = app.compare_sheet()
            self.assertEqual(response['column'], '8\n\n5\n13\n9')
            self.assertEqual(response['changed'], 1)
            self.assertEqual(response['unchanged'], 2)
            self.assertEqual(response['missing'], 1)
            # Check repeated Telethon sync doesn't double-count a message.
            with app.connect() as db:
                app.save_report(db, -1003160564432, 101, 176, now-100,
                    'R5G23506 Элмир Ф2\nСложний 7\nОдин1\nИтого 8')
            points = app.telegram_points(['R5G23506'], 'average', now-1000, now+5)
            self.assertEqual(points['R5G23506']['count'], 2)
            self.assertEqual(points['R5G23506']['points'], 9)

if __name__ == '__main__':
    unittest.main()
