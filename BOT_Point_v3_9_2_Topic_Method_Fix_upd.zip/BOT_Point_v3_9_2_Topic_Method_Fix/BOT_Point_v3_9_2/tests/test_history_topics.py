"""Unit tests for safe Telethon topic validation and fallback (no Telegram access)."""
import asyncio
import importlib.util
import sys
import types
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch

if importlib.util.find_spec('telethon') is None:
    telethon = types.ModuleType('telethon')
    telethon.TelegramClient = object
    telethon.utils = NS(get_peer_id=lambda e: e.id)
    errors = types.ModuleType('telethon.errors')
    class RPCError(Exception):
        pass
    errors.RPCError = RPCError
    errors.FloodWaitError = type('FloodWaitError',(RPCError,),{})
    funcs = types.ModuleType('telethon.tl.functions')
    messages = types.ModuleType('telethon.tl.functions.messages')
    messages.GetForumTopicsRequest = lambda **kw: ('list',kw)
    messages.GetForumTopicsByIDRequest = lambda **kw: ('by_id',kw)
    funcs.messages = messages
    sys.modules.update({'telethon':telethon,'telethon.errors':errors,
                        'telethon.tl':types.ModuleType('telethon.tl'),
                        'telethon.tl.functions':funcs,
                        'telethon.tl.functions.messages':messages})

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import history_sync as hs

NOW = datetime.now(timezone.utc)
CUT = NOW - timedelta(days=30)

def message(id, top=None, reply=None, days=1):
    r = NS(reply_to_top_id=top, reply_to_msg_id=reply) if top is not None or reply is not None else None
    return NS(id=id, reply_to=r, date=NOW-timedelta(days=days), message='fake')

class DummyClient:
    def __init__(self, records, mode='error'):
        self.records = records
        self.mode = mode
        self.calls=[]
    async def iter_messages(self, entity, reply_to=None, limit=None):
        self.calls.append(reply_to)
        if reply_to is not None:
            if self.mode=='error':
                raise hs.RPCError('RPCError 400: TOPIC_ID_INVALID (caused by GetRepliesRequest)')
            if self.mode=='human_error':
                raise hs.RPCError('The specified topic ID is invalid (caused by GetRepliesRequest)')
            if self.mode=='unrelated_error':
                raise hs.RPCError('USER_BANNED_IN_CHANNEL')
        for rec in self.records:
            yield rec

class HistoryTests(unittest.TestCase):
    def test_topic_filter(self):
        self.assertTrue(hs.belongs_to_topic(message(200, top=176, reply=199),176))
        self.assertTrue(hs.belongs_to_topic(message(201,reply=176),176))
        self.assertTrue(hs.belongs_to_topic(message(176),176))
        self.assertFalse(hs.belongs_to_topic(message(200,top=177,reply=199),176))
        self.assertFalse(hs.belongs_to_topic(message(200),176))
        self.assertFalse(hs.belongs_to_topic(message(200,reply=145),176))

    def test_fallback_reads_only_right_topic_and_30_days(self):
        recs=[message(205,top=176,reply=200),message(206,top=177,reply=190),
              message(207),message(208,reply=176),message(176),message(209,top=176,days=45)]
        client=DummyClient(recs)
        async def collect():
            return [m.id async for m in hs.iter_selected_messages(client,'entity',176,CUT)]
        self.assertEqual(asyncio.run(collect()),[205,208,176])
        self.assertEqual(client.calls,[176,None])

    def test_human_readable_error_also_falls_back(self):
        client=DummyClient([message(202,top=176)],mode='human_error')
        async def collect():
            return [m.id async for m in hs.iter_selected_messages(client,'entity',176,CUT)]
        self.assertEqual(asyncio.run(collect()),[202])

    def test_unexpected_api_error_is_not_hidden(self):
        client=DummyClient([],mode='unrelated_error')
        async def collect():
            return [m.id async for m in hs.iter_selected_messages(client,'entity',176,CUT)]
        with self.assertRaises(hs.RPCError):
            asyncio.run(collect())

    def test_missing_topic_zero_results_is_error(self):
        client=DummyClient([message(206,top=177)])
        async def collect():
            return [m.id async for m in hs.iter_selected_messages(client,'entity',176,CUT)]
        with self.assertRaisesRegex(ValueError,'не удалось определить'):
            asyncio.run(collect())

    def test_read_topics_and_match(self):
        class TopicClient:
            async def __call__(self, request):
                if request[0]=='list':
                    assert request[1]['peer'] == 'chat'
                    return NS(topics=[NS(id=176,title='Сборка'),NS(id=177,title='Другая')])
                assert request[1]['peer'] == 'chat'
                return NS(topics=[])
        async def run():
            return await hs.ensure_topic(TopicClient(),'chat',176)
        self.assertEqual(asyncio.run(run()).title,'Сборка')


    def test_exact_topic_lookup_uses_messages_namespace_and_peer(self):
        class TopicClient:
            def __init__(self):
                self.calls = []
            async def __call__(self, request):
                self.calls.append(request)
                if request[0] == 'list':
                    return NS(topics=[])
                return NS(topics=[NS(id=176,title='Нужная тема')])
        client=TopicClient()
        async def run():
            return await hs.ensure_topic(client, 'chat', 176)
        result=asyncio.run(run())
        self.assertEqual(result.id,176)
        self.assertEqual(client.calls[0][0], 'list')
        self.assertEqual(client.calls[0][1]['peer'], 'chat')
        self.assertEqual(client.calls[1], ('by_id', {'peer':'chat','topics':[176]}))

    def test_missing_topic_shows_available_ids(self):
        class TopicClient:
            async def __call__(self, request):
                if request[0]=='list':
                    assert request[1]['peer'] == 'chat'
                    return NS(topics=[NS(id=176,title='Сборка'),NS(id=177,title='Другая')])
                assert request[1]['peer'] == 'chat'
                return NS(topics=[])
        async def run():
            return await hs.ensure_topic(TopicClient(),'chat',999)
        with self.assertRaisesRegex(ValueError, '176: Сборка'):
            asyncio.run(run())

if __name__=='__main__':
    unittest.main()
