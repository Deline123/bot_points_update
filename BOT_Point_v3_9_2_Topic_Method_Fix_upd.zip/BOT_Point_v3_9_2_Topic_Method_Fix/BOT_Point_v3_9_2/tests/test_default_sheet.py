"""Test local persistence of the preferred Google spreadsheet."""
import tempfile
from pathlib import Path
from unittest import TestCase
from unittest.mock import Mock, patch

from test_logic import app, fake

class DefaultSheetTests(TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_db = app.DB
        self.old_initial = app.INITIAL_SHEET_URL
        app.DB = Path(self.tmp.name) / 'points.db'
        app.INITIAL_SHEET_URL = ''
        app.init_db()

    def tearDown(self):
        app.DB = self.old_db
        app.INITIAL_SHEET_URL = self.old_initial
        self.tmp.cleanup()

    def test_first_launch_and_persistence(self):
        self.assertEqual(app.get_default_sheet_url(), '')
        url = 'https://docs.google.com/spreadsheets/d/sheetA123/edit#gid=1448578665'
        app.save_default_sheet_url(url)
        self.assertEqual(app.get_default_sheet_url(), url)
        self.assertEqual(app.sheet_default()['url'], url)
        app.init_db()  # Simulate restart: schema initialization must not wipe the link.
        self.assertEqual(app.get_default_sheet_url(), url)

    def test_initial_env_fallback_and_override(self):
        app.INITIAL_SHEET_URL = 'https://docs.google.com/spreadsheets/d/initial123/edit#gid=0'
        self.assertEqual(app.get_default_sheet_url(), app.INITIAL_SHEET_URL)
        override = 'https://docs.google.com/spreadsheets/d/changed456/edit#gid=5'
        app.save_default_sheet_url(override)
        self.assertEqual(app.get_default_sheet_url(), override)

    def test_successful_load_saves_url(self):
        original = 'https://docs.google.com/spreadsheets/d/valid1/edit#gid=1448578665'
        fake.request.get_json = lambda **kwargs: {'url': original}
        response = Mock()
        response.content = b'part,points\nR5G23506,9\n'
        response.text = response.content.decode()
        response.headers = {'content-type':'text/csv'}
        response.raise_for_status.return_value = None
        with patch.object(app.requests, 'get', return_value=response) as req:
            data = app.sheet()
        self.assertEqual(data['gid'], '1448578665')
        self.assertEqual(data['rows'][1], ['R5G23506', '9'])
        self.assertEqual(app.get_default_sheet_url(), original)
        self.assertEqual(req.call_args.kwargs['params']['gid'], '1448578665')

    def test_bad_url_does_not_replace_saved_link(self):
        app.save_default_sheet_url('https://docs.google.com/spreadsheets/d/safe123/edit#gid=0')
        fake.request.get_json = lambda **kwargs: {'url':'https://evil.example/test'}
        result, status = app.sheet()
        self.assertEqual(status, 400)
        self.assertIn('ссылка', result['error'])
        self.assertEqual(app.get_default_sheet_url(), 'https://docs.google.com/spreadsheets/d/safe123/edit#gid=0')

    def test_failed_request_does_not_replace_saved_link(self):
        app.save_default_sheet_url('https://docs.google.com/spreadsheets/d/safe123/edit#gid=0')
        fake.request.get_json = lambda **kwargs: {'url':'https://docs.google.com/spreadsheets/d/new123/edit#gid=8'}
        with patch.object(app.requests, 'get', side_effect=app.requests.RequestException('network error')):
            result, status = app.sheet()
        self.assertEqual(status, 400)
        self.assertEqual(app.get_default_sheet_url(), 'https://docs.google.com/spreadsheets/d/safe123/edit#gid=0')
