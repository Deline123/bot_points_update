@echo off
chcp 65001 >nul
cd /d "%~dp0"
title BOT Point - Telegram Topics
python history_sync.py topics
if errorlevel 1 (
    echo.
    echo Prover'te .env i dostup k gruppe. Dlya vhoda: login_telegram.bat
)
echo.
pause
